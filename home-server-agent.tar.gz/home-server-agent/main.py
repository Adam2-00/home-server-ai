#!/usr/bin/env python3
"""
Home Server AI Setup Agent
Main entry point for the home server installation automation.
"""
import os
import sys
import json
import argparse
import uuid
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

# Version info
__version__ = "1.0.0"
__author__ = "Home Server AI Team"

# Import modules
from hardware_detector import detect_hardware, HardwareProfile
from interview import conduct_interview, UserRequirements
from planner import create_plan, InstallationPlan
from executor import ExecutionEngine, StateManager
from error_recovery import ErrorRecoveryEngine
from web_config import WebConfigServer
from preflight import run_preflight_checks
from config_validator import validate_config_file, validate_requirements

# Setup logging with rotation
from logging.handlers import RotatingFileHandler
import signal
import atexit

# Global state for cleanup
_state_manager = None
_web_server = None

def _cleanup():
    """Cleanup function called on exit."""
    global _state_manager, _web_server
    if _state_manager:
        try:
            _state_manager.close()
        except Exception:
            pass

def _signal_handler(signum, frame):
    """Handle interrupt signals gracefully."""
    print("\n\n⚠️  Received interrupt signal, cleaning up...")
    _cleanup()
    sys.exit(130)

# Register cleanup handlers
atexit.register(_cleanup)
signal.signal(signal.SIGINT, _signal_handler)
signal.signal(signal.SIGTERM, _signal_handler)

# Setup logging with rotation
log_handler = RotatingFileHandler('setup.log', maxBytes=5*1024*1024, backupCount=3)
log_handler.setLevel(logging.INFO)
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[log_handler, console_handler]
)
logger = logging.getLogger(__name__)


def load_config(path: str = "config.json") -> Optional[dict]:
    """Load configuration from file with validation."""
    if os.path.exists(path):
        with open(path, 'r') as f:
            config = json.load(f)
        
        # Validate the loaded config
        is_valid, errors, warnings = validate_requirements(config)
        
        if not is_valid:
            print(f"⚠️  Configuration validation errors in {path}:")
            for error in errors:
                print(f"   ❌ {error}")
            print()
        
        if warnings:
            print(f"⚠️  Configuration warnings:")
            for warning in warnings:
                print(f"   ⚠️  {warning}")
            print()
        
        return config
    return None


def save_session_data(session_id: str, hardware: dict, requirements: dict, plan: dict):
    """Save session for resumability."""
    data = {
        'session_id': session_id,
        'hardware': hardware,
        'requirements': requirements,
        'plan': plan
    }
    with open(f'session_{session_id}.json', 'w') as f:
        json.dump(data, f, indent=2)


def check_prerequisites() -> bool:
    """Check basic prerequisites before starting."""
    print("🔍 Checking prerequisites...")
    logger.info("Checking prerequisites")
    
    # Check Python version
    if sys.version_info < (3, 11):
        print("❌ Python 3.11+ required")
        logger.error(f"Python version too old: {sys.version_info}")
        return False
    
    # Check if running on Linux
    if not os.path.exists('/etc/os-release'):
        print("❌ This tool is designed for Linux systems")
        logger.error("Not running on Linux")
        return False
    
    print("✓ Basic prerequisites met\n")
    logger.info("Prerequisites check passed")
    return True


def run_preflight_validation(storage_path: str = None) -> bool:
    """Run comprehensive pre-flight validation."""
    return run_preflight_checks(storage_path, verbose=True)


def print_progress_bar(current: int, total: int, width: int = 40):
    """Print a progress bar."""
    percent = current / total if total > 0 else 0
    filled = int(width * percent)
    bar = '█' * filled + '░' * (width - filled)
    print(f"\r   Progress: |{bar}| {current}/{total} ({int(percent*100)}%)", end='', flush=True)
    if current >= total:
        print()


def run_setup_flow(args):
    """Main setup flow with comprehensive error handling."""
    global _state_manager, _web_server
    
    session_id = str(uuid.uuid4())[:8]
    logger.info(f"Starting setup session: {session_id}")
    
    # Ensure we're in a writable directory
    work_dir = Path.cwd()
    if not os.access(work_dir, os.W_OK):
        print(f"❌ No write permission in {work_dir}")
        print("   Please run from a directory where you have write access")
        logger.error(f"No write permission in {work_dir}")
        return 1
    
    print("="*60)
    print("  🏠 Home Server AI Setup Agent")
    print("  Your AI-powered home server installer")
    print("="*60)
    print(f"\nSession ID: {session_id}")
    print(f"Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("This will help you set up a complete home server stack.\n")
    
    try:
        # Initialize state manager
        state = StateManager()
        _state_manager = state
    except sqlite3.Error as e:
        print(f"❌ Database error: {e}")
        print("   Check disk space and permissions")
        logger.error(f"State manager initialization failed: {e}")
        return 1
    except Exception as e:
        print(f"❌ Failed to initialize state manager: {e}")
        logger.exception("State manager initialization failed")
        return 1
    
    # Initialize error recovery
    try:
        api_key = os.getenv('OPENAI_API_KEY')
        error_recovery = ErrorRecoveryEngine(api_key)
    except Exception as e:
        logger.warning(f"Failed to initialize error recovery: {e}")
        error_recovery = None
    
    # Check for existing session to resume
    if args.resume:
        print(f"📋 Resuming session: {args.resume}")
        logger.info(f"Resuming session: {args.resume}")
        try:
            session_data = state.get_session(args.resume)
            if session_data:
                hardware = session_data['hardware_profile']
                requirements = session_data['user_requirements']
                plan = session_data['plan_json']
                session_id = args.resume
                print(f"   ✓ Loaded session with {len(plan.get('steps', []))} steps")
            else:
                print(f"❌ Session {args.resume} not found")
                logger.error(f"Session {args.resume} not found")
                print(f"   Run 'python dashboard.py' to see available sessions")
                return 1
        except (json.JSONDecodeError, KeyError) as e:
            print(f"❌ Session data corrupted: {e}")
            logger.error(f"Session data corrupted: {e}")
            print("   The session database may be damaged. Try starting a new session.")
            return 1
    else:
        # Step 1: Hardware Detection
        print("\n📊 Step 1: Detecting hardware...")
        logger.info("Detecting hardware")
        try:
            hardware_profile = detect_hardware()
            print(f"   CPU: {hardware_profile.cpu_model} ({hardware_profile.cpu_cores} cores)")
            print(f"   RAM: {hardware_profile.ram_gb:.1f} GB")
            print(f"   Disk: {hardware_profile.disk_gb}")
            print(f"   OS: {hardware_profile.distro} {hardware_profile.distro_version}")
            
            if hardware_profile.potential_issues:
                print("\n⚠️  Potential issues detected:")
                for issue in hardware_profile.potential_issues:
                    print(f"   - {issue}")
                logger.warning(f"Potential issues: {hardware_profile.potential_issues}")
            
            hardware = hardware_profile.to_dict()
        except Exception as e:
            print(f"❌ Hardware detection failed: {e}")
            logger.exception("Hardware detection failed")
            print("   Continuing with default hardware profile")
            hardware = {
                'cpu_cores': 2,
                'cpu_threads': 4,
                'cpu_model': 'Unknown',
                'ram_gb': 4.0,
                'disk_gb': {'/': 50.0},
                'distro': 'unknown',
                'has_docker': False,
                'has_curl': True
            }
        
        # Step 2: User Requirements
        print("\n📝 Step 2: Gathering requirements...")
        logger.info("Gathering requirements")
        
        try:
            if args.web:
                print("   Launching web configuration interface...")
                server = WebConfigServer(port=args.port)
                _web_server = server
                server.run(blocking=False)
                print(f"   🌐 Open http://localhost:{args.port} in your browser")
                print("   Waiting for configuration...")
                if not server.wait_for_config():
                    print("❌ Configuration timeout or cancelled")
                    logger.error("Web configuration timeout or cancelled")
                    return 1
                requirements = load_config()
                if not requirements:
                    print("❌ Configuration file not found after web submission")
                    return 1
                print("   ✓ Configuration received from web interface")
            elif args.config:
                print(f"   Loading config from {args.config}")
                requirements = load_config(args.config)
                if not requirements:
                    print(f"❌ Config file not found or invalid: {args.config}")
                    logger.error(f"Config file not found or invalid: {args.config}")
                    return 1
                print(f"   ✓ Loaded config from {args.config}")
            else:
                interview_result = conduct_interview()
                requirements = interview_result.to_dict()
                
                # Check if user prefers web UI for additional configuration
                if requirements.get('preferred_ui') == 'web' and not args.no_web:
                    print("\n🌐 Switching to web interface for additional configuration...")
                    server = WebConfigServer(port=args.port)
                    _web_server = server
                    server.run(blocking=False)
                    print(f"   Open http://localhost:{args.port} in your browser")
                    print("   (Press Ctrl+C to skip and use CLI values)")
                    
                    import signal
                    def timeout_handler(signum, frame):
                        raise TimeoutError("Web config timeout")
                    
                    signal.signal(signal.SIGALRM, timeout_handler)
                    signal.alarm(60)  # 60 second timeout for web config
                    
                    try:
                        if server.wait_for_config(timeout=60):
                            web_config = load_config()
                            if web_config:
                                # Merge web config, keeping interview values as defaults
                                for key, value in web_config.items():
                                    if value:  # Only overwrite if web provided a value
                                        requirements[key] = value
                                print("   ✓ Additional configuration received from web interface")
                    except TimeoutError:
                        print("   Web config timeout, continuing with CLI values")
                    finally:
                        signal.alarm(0)
            
            print(f"   Selected: {', '.join(requirements.get('use_cases', []))}")
            logger.info(f"User selected: {requirements.get('use_cases', [])}")
        except KeyboardInterrupt:
            print("\n\n⚠️  Setup cancelled by user")
            logger.info("User cancelled during requirements gathering")
            return 130
        except Exception as e:
            print(f"❌ Error gathering requirements: {e}")
            logger.exception("Requirements gathering failed")
            return 1
        
        # Step 3: Generate Plan
        print("\n🧠 Step 3: Generating installation plan...")
        logger.info("Generating installation plan")
        
        # Check for AI configuration
        ai_provider = requirements.get('ai_provider')
        if ai_provider:
            print(f"   Using AI provider: {ai_provider} ({requirements.get('ai_model', 'default model')})")
        elif os.getenv('OPENAI_API_KEY'):
            print("   Using OpenAI from environment")
        elif os.getenv('ANTHROPIC_API_KEY'):
            print("   Using Anthropic Claude from environment")
        else:
            print("   ⚠️  No AI provider configured, using template plan")
            print("   For AI-generated custom plans, configure an AI provider in the interview")
            logger.info("Using template plan (no AI provider configured)")
        
        try:
            plan_obj = create_plan(hardware, requirements)
            plan = plan_obj.to_dict()
            print(f"   ✓ Plan: {plan['title']}")
            print(f"   ✓ Steps: {len(plan['steps'])}")
            print(f"   ✓ Est. time: {plan['estimated_time_minutes']} minutes")
            
            if plan['known_issues']:
                print("\n   Known issues for this setup:")
                for issue in plan['known_issues']:
                    print(f"   - {issue}")
            
            logger.info(f"Generated plan with {len(plan['steps'])} steps")
        except Exception as e:
            print(f"   Error generating plan: {e}")
            logger.exception("Error generating plan")
            return 1
    
    # Save session data
    state.create_session(session_id, hardware, requirements, plan)
    logger.info(f"Session saved: {session_id}")
    
    if args.plan_only:
        print("\n📋 Plan only mode - not executing")
        print(json.dumps(plan, indent=2))
        return 0
    
    # Run pre-flight validation
    storage_path = requirements.get('storage_path') if args.config else None
    if not run_preflight_validation(storage_path):
        print("❌ Pre-flight checks failed. Please fix the issues above and try again.")
        logger.error("Pre-flight validation failed")
        return 1
    
    # Step 4: Execute Plan
    print("\n🚀 Step 4: Executing installation plan...")
    print("-"*60)
    logger.info("Starting plan execution")
    
    if not args.yes:
        confirm = input("\nProceed with installation? [Y/n]: ").strip().lower()
        if confirm and confirm not in ['y', 'yes']:
            print("Cancelled.")
            logger.info("User cancelled before execution")
            return 0
    
    executor = ExecutionEngine(
        state_manager=state,
        dry_run=args.dry_run,
        auto_approve=args.yes
    )
    executor.session_id = session_id
    
    # Execute with progress tracking
    steps = plan.get('steps', [])
    total_steps = len(steps)
    completed_steps = state.get_completed_steps(session_id)
    
    print(f"\n📊 Progress: 0/{total_steps} steps")
    
    results = executor.execute_plan(plan, resume_from=args.resume_step or 0)
    
    # Step 5: Summary
    print("\n" + "="*60)
    print("  📊 Installation Summary")
    print("="*60)
    
    success_count = sum(1 for r in results if r.success)
    fail_count = len(results) - success_count
    
    print(f"\n   Total steps executed: {len(results)}")
    print(f"   ✓ Successful: {success_count}")
    print(f"   ✗ Failed: {fail_count}")
    
    if fail_count == 0:
        print("\n🎉 All steps completed successfully!")
        print("\n✓ Your home server is ready!")
        state.complete_session(session_id, success=True)
        logger.info(f"Session {session_id} completed successfully")
        
        # Post-install notes
        if plan.get('post_install_notes'):
            print("\n📋 Next steps:")
            for note in plan['post_install_notes']:
                print(f"   • {note}")
        
        # Print access URLs
        print("\n🔗 Access your services:")
        if requirements.get('want_adguard'):
            print("   • AdGuard Home: http://localhost:3000")
        if requirements.get('want_jellyfin'):
            print("   • Jellyfin: http://localhost:8096")
        if requirements.get('want_tailscale'):
            print("   • Tailscale: Run 'tailscale status' to see your network")
        
        print(f"\n💾 Session saved: {session_id}")
        print(f"📄 Log file: {work_dir}/setup.log")
        return 0
    else:
        print(f"\n⚠️  Some steps failed.")
        print(f"\n💾 Session saved: {session_id}")
        print(f"🔄 Resume with: python main.py --resume {session_id}")
        print(f"📄 Check logs: {work_dir}/setup.log")
        state.complete_session(session_id, success=False)
        logger.warning(f"Session {session_id} completed with failures")
        return 1


def main():
    parser = argparse.ArgumentParser(
        description=f'Home Server AI Setup Agent v{__version__}',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py                    # Interactive setup
  python main.py --web              # Use web configuration
  python main.py --config cfg.json  # Load config from file
  python main.py --dry-run          # Show what would be done
  python main.py --resume abc123    # Resume failed session
  python main.py --plan-only        # Generate plan without executing
  python main.py --version          # Show version info
        """
    )
    
    parser.add_argument('--version', action='version', version=f'%(prog)s {__version__}')
    parser.add_argument('--web', action='store_true',
                       help='Use web interface for configuration')
    parser.add_argument('--no-web', action='store_true',
                       help='Disable web interface even if user requests it')
    parser.add_argument('--port', type=int, default=8080,
                       help='Web server port (default: 8080)')
    parser.add_argument('--config', type=str,
                       help='Load configuration from JSON file')
    parser.add_argument('--dry-run', action='store_true',
                       help='Show plan without executing')
    parser.add_argument('--plan-only', action='store_true',
                       help='Generate plan and exit')
    parser.add_argument('--yes', '-y', action='store_true',
                       help='Auto-approve all steps')
    parser.add_argument('--resume', type=str, metavar='SESSION_ID',
                       help='Resume a previous session')
    parser.add_argument('--resume-step', type=int, default=0,
                       help='Resume from specific step number')
    
    args = parser.parse_args()
    
    # Check prerequisites
    if not check_prerequisites():
        return 1
    
    try:
        return run_setup_flow(args)
    except KeyboardInterrupt:
        print("\n\n⚠️  Setup interrupted by user")
        return 130
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
